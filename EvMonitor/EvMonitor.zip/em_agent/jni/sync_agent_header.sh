#!/bin/sh
aosp=/mnt/extra/aosp
filename=em_agent.h
art_path=$aosp/art/runtime/$filename
sudo cp $filename $art_path