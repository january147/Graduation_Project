em_agent.c是EvMonitor_agent的源代码, 用户用户端控制EvMonitor, 该程序也运行在手机端, 需要通过adb shell进入手机终端启动
